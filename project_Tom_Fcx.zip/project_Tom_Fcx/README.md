INTRO : je souhaites créer un système de flashcards qui va en fonction de mes bonnes ou mauvaises réponses, me redonner les fiches à réviser, 
d'abord chaque jour pour la 1ère semaine puis,  tous les 2 jours dans la seconde, etc... Il espacera de plus en plus mes révisions de ces chapitres. 
Je crois en la méthode de la répétition espacé théorisé par le philosophe allemande Hermann Ebbinghaus.
Pour en savoir plus : https://www.youtube.com/watch?v=n3CkA3Qc8kY




Fonctions supplémentaires à implémenter : lancement du programme automatique dès le début de Windows, compte à rebours, 
lecture de la flashcard par assistant vocal. Enfin implémenter l'IA décrite dans l'intro.